import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {

  constructor(private commonService: CommonService,
    private router: Router) { }
userList;
  ngOnInit() {
    this.getUserList()
  }
getUserList(){
  this.commonService.getUserList().subscribe(res => {
    this.userList = res['data'];
    console.log(this.userList)
  
  })
}
viewUsr(id){
  let idx =  this.userList.findIndex((x)=> {return x.id == id})
  this.commonService.userDetails =  this.userList[idx]
  this.router.navigate(['/user', id])
}
deleteItem(id){
 let idx =  this.userList.findIndex((x)=> {return x.id == id})
this.userList.splice(idx, 1)
}
}
